#include "ListArray.h"

using namespace std;

int main(){
    ListArray lista(6,8);

    return 0;
}